<?php 
require("../admin/db_con.php");
if(isset($_POST['submit'])){
    $full_name = $_POST['full_name'];
    $username = $_POST['username'];
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $password = $_POST['password'];
    $c_password = $_POST['c_password'];
    date_default_timezone_set("Asia/Dhaka");
    $registe_date = date("Y-m-d h:i:sa");
    $input_error = array();
    if(empty($full_name)){
        $input_error['full_name'] = "* Name is required";
    }
    if(empty($username)){
        $input_error['username'] = "* Username is required";
    }
    if(empty($fname)){
        $input_error['fname'] = "* Father Name is required";
    }
    if(empty($mname)){
        $input_error['mname'] = "* Mother Name is required";
    }
    if(empty($phone)){
        $input_error['phone'] = "* Phone Number is required";
    }
    if(empty($email)){
        $input_error['email'] = "* email Address is required";
    }
    if(empty($address)){
        $input_error['address'] = "* Name is required";
    }
    if(empty($password)){
        $input_error['password'] = " *Password is required";
    }
    if(empty($c_password)){
        $input_error['c_password'] = "* Confirm Password is required";
    }

    if(count($input_error) == 0){
      if(strlen($username) > 5){
        if(strlen($password) > 8 ){
          if($password == $c_password){
            $username_unique = mysqli_query($db_con , "SELECT * FROM `user_register_data` WHERE `username` = '$username'");
            if(mysqli_num_rows($username_unique) == 0){
              $email_unique = mysqli_query($db_con , "SELECT * FROM `user_register_data` WHERE `email` = '$email'");
              if(mysqli_num_rows($email_unique) == 0){
                  $password = md5($password);
                  $insert = mysqli_query($db_con , "INSERT INTO `user_register_data`(`name`, `username`, `father name`, `mother name`, `phone`, `email`, `address`, `password`, `register time`, `status`) VALUES ('$full_name','$username','$fname','$mname','$phone','$email','$address','$password','$registe_date','Inactive')");
                  if($insert){
                    echo "<script>
                    alert('Successfully Register You Account');
                    </script>";
                    // header("location:register_admin_index_form.php");  
                  }
              }else{
                $input_error['email'] = "* email is already exist";
              }
            }else{
              $input_error['username'] = "* Username is already exist";
            }
          }else{
            $input_error['c_password'] = "* Password cannot match";
          }
        }else{
          $input_error['password'] = " * Password must be above 8 character";
        }
      }else{
        $input_error['username'] = "* Username must be above 5 character";
      }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Form -</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="wrapper">
    <h2>Registration</h2>
    <form action="" method="post">
        <div class="two_column">
      <div class="input-box">
        <label for="full_name">Name:</label>
        <input type="text" name="full_name" placeholder="Enter your name" >
        <span style="color: red;"><?php if(isset($input_error['full_name'])){echo $input_error['full_name'];}?></span>
      </div>
      <div class="input-box">
        <label for="username">User Name :</label>
        <input type="text" name="username" placeholder="Enter your username" >
        <span style="color: red;"><?php if(isset($input_error['username'])){echo $input_error['username'];}?></span>
      </div>
        </div>
        <div class="two_column">
      <div class="input-box">
        <label for="fname">Father Name :</label>
        <input type="text" name="fname" placeholder="Enter your father name" >
        <span style="color: red;"><?php if(isset($input_error['fname'])){echo $input_error['fname'];}?></span>
      </div>
      <div class="input-box">
        <label for="mname">Mother Name :</label>
        <input type="text" name="mname" placeholder="Enter your mother name" >
        <span style="color: red;"><?php if(isset($input_error['mname'])){echo $input_error['mname'];}?></span>
      </div>
        </div>
        <div class="two_column">
      <div class="input-box">
        <label for="phone">Phone :</label>
        <input type="text" name="phone" placeholder="Enter your phone number" >
        <span style="color: red;"><?php if(isset($input_error['phone'])){echo $input_error['phone'];}?></span>
      </div>
      <div class="input-box">
        <label for="email">email :</label>
        <input type="email" name="email" placeholder="Enter your email address" >
        <span style="color: red;"><?php if(isset($input_error['email'])){echo $input_error['email'];}?></span>
      </div>
        </div>
        <div class="two_column">
      <div class="input-box">
        <label for="address">Address :</label>
        <input type="text" name="address" placeholder="Enter your address" >
        <span style="color: red;"><?php if(isset($input_error['address'])){echo $input_error['address'];}?></span>
      </div>
        </div>
        <div class="two_column">
      <div class="input-box">
        <label for="password">Password :</label>
        <input type="password" name="password" placeholder="Create password" >
        <span style="color: red;"><?php if(isset($input_error['password'])){echo $input_error['password'];}?></span>
      </div>
      <div class="input-box">
        <label for="c_password">Confirm Password :</label>
        <input type="password" name="c_password" placeholder="Again type your password" >
        <span style="color: red;"><?php if(isset($input_error['c_password'])){echo $input_error['c_password'];}?></span>
      </div>
        </div>
      <div class="input-box button">
        <input type="Submit" value="Register Now" name="submit">
      </div>
      <div class="text">
        <h3>Already have an account? <a href="#">Login now</a></h3>
      </div>
    </form>
  </div>
<script src="js/script.js"></script>
</body>
</html>